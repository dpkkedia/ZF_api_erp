ERP API Documentation
Get asset list
$ curl -v -X GET {URL:port}/api/erp
Get specific asset with ID
$ curl -v -X GET {URL:port}/api/erp/{id}
Create asset (POST)
$ curl -d "asset_id=1234&brand=Dell&name=X1203&price=500&ram_type=DDR2&ram_size=8" -v -X POST {URL:port}/api/erp
Delete asset (DELETE)
$ curl -v -X DELETE {URL:port}/api/erp/{id}
Configuration / Installation:
Place the folder in Htdocs of Apache server.
Place Vhost: 

            <VirtualHost *:9092>
                ServerName api.application.local
                ServerAdmin shankey.kedia@gmail.com

                ## Vhost docroot
                DocumentRoot "PATH_TILL_HTDOCS/ZF3/public"
                <Directory "PATH_TILL_HTDOCS/ZF3/public">
                    DirectoryIndex index.php
                    AllowOverride All
                    Order allow,deny
                    Allow from all
                    <IfModule mod_authz_core.c>
                        Require all granted
                    </IfModule>
                </Directory>
                ## Custom fragment
                AddType application/x-httpd-php .php	
            </VirtualHost>
        
FILE PATH : ZF3\module\Application\config\module.config.php 
Configure base_path in the mentioned file 
'base_path' => 'http://localhost:9092',
FILE PATH : ZF3\config\autoload\global.php 
Configure Database Connection in the mentioned file 
'params' => [ 'host' => 'localhost', 'port' => '3306', 'user' => 'root', 'password' => 'vagrant', 'dbname' => 'test', 'driverOptions' => [ 1002 => 'SET NAMES utf8' ]
MySQL Database Schema:
CREATE TABLE `erp_data` ( `id` INT(11) NOT NULL AUTO_INCREMENT, `asset_id` MEDIUMINT(9) NULL DEFAULT NULL, `brand` VARCHAR(99) NULL DEFAULT NULL, `name` VARCHAR(99) NULL DEFAULT NULL, `price` FLOAT NULL DEFAULT '0', `ram_type` VARCHAR(50) NULL DEFAULT '0', `ram_size` INT(11) NULL DEFAULT '0', PRIMARY KEY (`id`) );
Note:
API Key used are:
asset_id
brand
name
price
ram_type
ram_size
Please have a note on the API methods (GET, POST, DELETE).
Asset ID is unique.
Price should be greater than 0.
Keys provided are mandatory.
For the sake of Keeping application minimal Authentication Token is not implemented.
Added filter within framework to involve soft validation.
For sake of easyness POSTMAN application can be used for CURL.