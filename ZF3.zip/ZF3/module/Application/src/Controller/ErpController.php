<?php

namespace Application\Controller;

use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
use Zend\Json\Json;
use Doctrine\ORM\EntityManager;
use Application\Entity\Erp;
use Application\Entity\Repository\ErpRepositoryRepository;
use Application\Form\ErpForm;
use Application\InputFilter\FormErpFilter;

class ErpController extends AbstractRestfulController {

    protected $entityManager;

    public function __construct(EntityManager $entityManager) {
        $this->entityManager = $entityManager;
    }

    public function getList() {
        $assets = $this->entityManager->getRepository(Erp::class)->findAll();

        if (!$assets) {
            return new JsonModel(['message' => 'No Asset found']);
        }

        $data = [];

        foreach ($assets as $asset) {
            $data[] = $asset->toArray();
        }

        return new JsonModel([
            'ERP' => $data,
        ]);
    }

    public function get($id) {
        $asset = $this->entityManager->getRepository(Erp::class)->find($id);

        if (!$asset) {
            return new JsonModel(['message' => 'Asset not found']);
        }

        return new JsonModel([
            'ERP' => $asset->toArray(),
        ]);
    }

    public function create($data) {
        $asset = new Erp();
        $form = new ErpForm();
        $request = $this->getRequest();
        $inputfilter = new FormErpFilter();
        $form->setInputFilter($inputfilter);
        $form->setData($request->getPost());
        $message = '';
        $assetExists = $this->entityManager->getRepository(Erp::class)->findOneBy(['asset_id' => $data['asset_id']]);
        if ($form->isValid() && ($data['price'] > 0) && !$assetExists && ($data['ram_type'] != '' && $data['ram_size'] != '')) {
            $asset->setAssetId($data['asset_id']);
            $asset->setBrand($data['brand']);
            $asset->setName($data['name']);
            $asset->setPrice($data['price']);
            $asset->setRamType($data['ram_type']);
            $asset->setRamSize($data['ram_size']);
            $this->entityManager->persist($asset);
            $this->entityManager->flush();
            $message = 'Asset registered successfully';
        } else {

            $message = $assetExists ? 'Please check asset values and Asset Id Already Exists' : 'Asset Validation failed';
        }


        return new JsonModel([
            'ERP' => $asset->toArray(),
            'message' => $message
        ]);
    }

    public function update($id, $data) {
        return new JsonModel([
            'ERP' => $asset->toArray(),
            'message' => 'Hola! Update is out of scope'
        ]);
    }

    public function delete($id) {
        if (!$id) {
            return new JsonModel(['message' => 'Id not found']);
        }

        $asset = $this->entityManager->getRepository(Erp::class)->findOneBy(['id' => $id]);

        if ($asset) {
            $this->entityManager->remove($asset);
            $this->entityManager->flush();
        }

        return new JsonModel([
            'message' => 'Asset deleted successfully!'
        ]);
    }

}
