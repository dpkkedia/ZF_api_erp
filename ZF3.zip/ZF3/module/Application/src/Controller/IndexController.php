<?php

/**
 * @author     Deepak Kedia
 */

namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Doctrine\ORM\EntityManager;
use Application\Entity\Erp;
use Application\Entity\Repository\ErpRepositoryRepository;

class IndexController extends AbstractActionController {

    protected $entityManager;

    public function __construct(EntityManager $entityManager) {
        $this->entityManager = $entityManager;
    }

    public function indexAction() {
        $data = [];
        $assets = $this->entityManager->getRepository(Erp::class)->findAll();
        foreach ($assets as $asset) {
            $data[] = $asset->toArray();
        }
        return new ViewModel(array(
            'assets' => $data
        ));
    }

}
