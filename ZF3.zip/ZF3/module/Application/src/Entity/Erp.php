<?php

namespace Application\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Entity(repositoryClass="Application\Entity\Repository\ErpRepository")
 * @ORM\Table(name="erp_data")
 */
class Erp {

    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="asset_id",unique=true, type="integer", nullable=false)
     */
    private $asset_id;

    /**
     * @var string
     *
     * @ORM\Column(name="brand", type="string", nullable=false)
     */
    private $brand;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", nullable=false)
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="price", type="integer", nullable=false)
     */
    private $price;

    /**
     * @var string
     *
     * @ORM\Column(name="ram_type", type="string", nullable=false)
     */
    private $ram_type;

    /**
     * @var string
     *
     * @ORM\Column(name="ram_size", type="integer", nullable=false)
     */
    private $ram_size;

    /**
     * @return int
     */
    public function getId() {
        return $this->id;
    }

    /**
     * @return int
     */
    public function getAssetId() {
        return $this->asset_id;
    }

    /**
     * @return string
     */
    public function getBrand() {
        return $this->brand;
    }

    /**
     * @return string
     */
    public function getName() {
        return $this->name;
    }

    /**
     * @return int
     */
    public function getPrice() {
        return $this->price;
    }

    /**
     * @return string
     */
    public function getRamType() {
        return $this->ram_type;
    }

    /**
     * @return int
     */
    public function getRamSize() {
        return $this->ram_size;
    }

    /**
     * @param int $asset_id
     */
    public function setAssetId($asset_id) {
        $this->asset_id = $asset_id;
    }

    /**
     * @param string $brand
     */
    public function setBrand($brand) {
        $this->brand = $brand;
    }

    /**
     * @param string $name
     */
    public function setName($name) {
        $this->name = $name;
    }

    /**
     * @param int $price
     */
    public function setPrice($price) {
        $this->price = $price;
    }

    /**
     * @param string $ram_type
     */
    public function setRamType($ram_type) {
        $this->ram_type = $ram_type;
    }

    /**
     * @param int $ram_size
     */
    public function setRamSize($ram_size) {
        $this->ram_size = $ram_size;
    }

    /**
     * Return this object in array form.
     *
     * @return array
     */
    public function toArray() {
        $data = get_object_vars($this);

        foreach ($data as $attribute => $value) {
            if (is_object($value)) {
                $data[$attribute] = get_object_vars($value);
            }
        }

        return $data;
    }

    public function getArrayCopy() {
        return get_object_vars($this);
    }

    /**
     * Fill this object from an array
     */
    public function exchangeArray($data) {
        if ($data != null) {
            foreach ($data as $attribute => $value) {
                if (!property_exists($this, $attribute)) {
                    continue;
                }
                $this->$attribute = $value;
            }
        }

        return $this;
    }

}
