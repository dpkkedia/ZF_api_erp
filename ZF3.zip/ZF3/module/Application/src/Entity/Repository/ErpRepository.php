<?php

namespace Application\Entity\Repository;

use Doctrine\ORM\EntityRepository;

class ErpRepository extends EntityRepository
{
    function test(){
        //In case we want to write the custom SQL Queries other than Entity
    }
}
