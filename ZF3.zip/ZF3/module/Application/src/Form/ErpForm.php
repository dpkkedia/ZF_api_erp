<?php

namespace Application\Form;

use Zend\Form\Form;

class ErpForm extends Form {

    public function __construct($name = 'erp', $options = array()) {
        parent::__construct($name, $options);

        $this->add([
            'name' => 'id',
            'attributes' => [
                'type' => 'hidden',
            ],
        ]);

        $this->add([
            'name' => 'asset_id',
            'attributes' => [
                'type' => 'text',
            ],
            'options' => [
                'label' => 'Asset Id',
            ],
        ]);
        $this->add([
            'name' => 'brand',
            'attributes' => [
                'type' => 'text',
            ],
            'options' => [
                'label' => 'Brand',
            ],
        ]);
        $this->add([
            'name' => 'name',
            'attributes' => [
                'type' => 'text',
            ],
            'options' => [
                'label' => 'Name',
            ],
        ]);

        $this->add([
            'name' => 'price',
            'attributes' => [
                'type' => 'text',
            ],
            'options' => [
                'label' => 'Price',
            ],
        ]);

        $this->add([
            'name' => 'ram_type',
            'attributes' => [
                'type' => 'text',
            ],
            'options' => [
                'label' => 'RAM Type',
            ],
        ]);

        $this->add([
            'name' => 'ram_size',
            'attributes' => [
                'type' => 'text',
            ],
            'options' => [
                'label' => 'RAM Size',
            ],
        ]);
    }

}
