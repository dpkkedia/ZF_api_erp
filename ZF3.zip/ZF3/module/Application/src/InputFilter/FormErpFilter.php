<?php

namespace Application\InputFilter;

use Zend\InputFilter\InputFilter;

class FormErpFilter extends InputFilter {

    public function __construct() {
        $this->add([
            'name' => 'id',
            'required' => false,
            'allowEmpty' => false,
            'filters' => [
            ],
            'validators' => [
            ],
        ]);

        $this->add([
            'name' => 'asset_id',
            'required' => true,
            'allowEmpty' => true,
            'filters' => [
                ['name' => 'StringTrim'],
            ],
            'validators' => [
                [
                    'name' => 'StringLength',
                    'options' => [
                        'min' => 1,
                        'max' => 50,
                    ],
                ],
            ],
        ]);

        $this->add([
            'name' => 'brand',
            'required' => true,
            'allowEmpty' => true,
            'filters' => [
                ['name' => 'StringTrim'],
            ],
            'validators' => [
                [
                    'name' => 'StringLength',
                    'options' => [
                        'min' => 2,
                        'max' => 50,
                    ],
                ],
            ],
        ]);
        $this->add([
            'name' => 'name',
            'required' => true,
            'allowEmpty' => true,
            'filters' => [
                ['name' => 'StringTrim'],
            ],
            'validators' => [
                [
                    'name' => 'StringLength',
                    'options' => [
                        'min' => 2,
                        'max' => 50,
                    ],
                ],
            ],
        ]);
        $this->add([
            'name' => 'price',
            'required' => true,
            'allowEmpty' => true,
            'filters' => [
                ['name' => 'StringTrim'],
            ],
            'validators' => [
                [
                    'name' => 'StringLength',
                    'options' => [
                        'min' => 1,
                        'max' => 50,
                    ],
                ],
            ],
        ]);
        $this->add([
            'name' => 'ram_size',
            'required' => true,
            'allowEmpty' => true,
            'filters' => [
                ['name' => 'StringTrim'],
            ],
            'validators' => [
                [
                    'name' => 'StringLength',
                    'options' => [
                        'min' => 1,
                        'max' => 50,
                    ],
                ],
            ],
        ]);
        $this->add([
            'name' => 'ram_type',
            'required' => true,
            'allowEmpty' => true,
            'filters' => [
                ['name' => 'StringTrim'],
            ],
            'validators' => [
                [
                    'name' => 'StringLength',
                    'options' => [
                        'min' => 1,
                        'max' => 50,
                    ],
                ],
            ],
        ]);
    }

}
